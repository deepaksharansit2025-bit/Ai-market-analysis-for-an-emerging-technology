const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const printBtn = document.getElementById("printBtn");

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

printBtn.addEventListener("click", () => window.print());
